﻿/*=============================================================================
 * 
 * Copyright © 2008 ESRI. All rights reserved. 
 * 
 * Use subject to ESRI license agreement.
 * 
 * Unpublished—all rights reserved.
 * Use of this ESRI commercial Software, Data, and Documentation is limited to
 * the ESRI License Agreement. In no event shall the Government acquire greater
 * than Restricted/Limited Rights. At a minimum Government rights to use,
 * duplicate, or disclose is subject to restrictions as set for in FAR 12.211,
 * FAR 12.212, and FAR 52.227-19 (June 1987), FAR 52.227-14 (ALT I, II, and III)
 * (June 1987), DFARS 227.7202, DFARS 252.227-7015 (NOV 1995).
 * Contractor/Manufacturer is ESRI, 380 New York Street, Redlands,
 * CA 92373-8100, USA.
 * 
 * SAMPLE CODE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 * INCLUDING THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE, ARE DISCLAIMED.  IN NO EVENT SHALL ESRI OR CONTRIBUTORS
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) SUSTAINED BY YOU OR A THIRD PARTY, HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT; STRICT LIABILITY; OR TORT ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SAMPLE CODE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE TO THE FULL EXTENT ALLOWED BY APPLICABLE LAW.
 * 
 * =============================================================================*/

using System;
using System.ComponentModel;
using System.IO;
using System.Runtime.InteropServices;
using Microsoft.Win32;

namespace ESRI.PrototypeLab.ProjectionEngine {
    /// <summary>
    /// Projection Engine Class
    /// </summary>
    public class Engine : IDisposable {
        public const double GLOBERADIUS = 6367444.65712259d;
        private bool m_disposed = false;
        private IntPtr m_pe = IntPtr.Zero;

        private GeodesicDistance m_gd = null;
        private GeodesicCoordinate m_gc = null;
        private GeogTran m_gt = null;
        private GeogGeog m_gg = null;

        [DllImport("kernel32.dll")]
        private static extern IntPtr LoadLibrary(string dllname);

        [DllImport("kernel32.dll")]
        private static extern bool FreeLibrary(IntPtr hModule);

        [DllImport("kernel32.dll")]
        private static extern IntPtr GetProcAddress(IntPtr hModule, string lpProcName);

        private delegate void GeodesicDistance(
            [In] double semiMajorAxis,
            [In] double eccentricity,
            [In] double longitude1,
            [In] double latitude1,
            [In] double longitude2,
            [In] double latitude2,
            [Out] out double distance,
            [Out] out double azimuthForward,
            [Out] out double azimuthBack);

        private delegate void GeodesicCoordinate(
            [In] double semiMajorAxis,
            [In] double eccentricity,
            [In] double longitude1,
            [In] double latitude1,
            [In] double distance,
            [In] double azimuth,
            [Out] out double longitude2,
            [Out] out double latitude2);

        private delegate IntPtr GeogTran(
            [In] int pegtcode);

        private delegate int GeogGeog(
            [In] IntPtr geogtrans,
            [In] int numpts,
            [In] double[] coord,
            [In] double[] h);

        public Engine(EngineType type) {
            string dll = null;
            switch (type) {
                case EngineType.ArcGISEngine:
                case EngineType.ArcGISDesktop:
                    dll = this.GetDesltopDll();
                    break;
                case EngineType.ArcGISExplorer:
                    dll = this.GetExplorerDll();
                    break;
                case EngineType.AcrobatReader:
                    dll = this.GetReaderDll();
                    break;
                case EngineType.Auto:
                    dll = this.GetDesltopDll();
                    if (string.IsNullOrEmpty(dll)) {
                        dll = this.GetExplorerDll();
                    }
                    if (string.IsNullOrEmpty(dll)) {
                        dll = this.GetReaderDll();
                    }
                    break;
            }
            if (string.IsNullOrEmpty(dll)) {
                throw new Exception("Path to projection engine dll is empty");
            }
            if (!File.Exists(dll)) {
                throw new Exception("Projection engine dll is missing");
            }

            // Load Projection Engine
            this.m_pe = Engine.LoadLibrary(dll);
            if (this.m_pe == IntPtr.Zero) {
                throw new Win32Exception(Marshal.GetLastWin32Error());
            }

            // Get Pointer to Function Calls
            IntPtr gd = Engine.GetProcAddress(this.m_pe, "pe_geodesic_distance");
            if (gd == IntPtr.Zero) {
                int err = Marshal.GetLastWin32Error();
                this.Dispose(false);
                throw new Win32Exception(err);
            }
            IntPtr gc = Engine.GetProcAddress(this.m_pe, "pe_geodesic_coordinate");
            if (gc == IntPtr.Zero) {
                int err = Marshal.GetLastWin32Error();
                this.Dispose(false);
                throw new Win32Exception(err);
            }
            IntPtr gt = Engine.GetProcAddress(this.m_pe, "pe_factory_geogtran");
            if (gt == IntPtr.Zero) {
                int err = Marshal.GetLastWin32Error();
                this.Dispose(false);
                throw new Win32Exception(err);
            }
            IntPtr gg = Engine.GetProcAddress(this.m_pe, "pe_geog1_to_geog2");
            if (gg == IntPtr.Zero) {
                int err = Marshal.GetLastWin32Error();
                this.Dispose(false);
                throw new Win32Exception(err);
            }

            // Create Delegates
            this.m_gd = (GeodesicDistance)Marshal.GetDelegateForFunctionPointer(gd, typeof(GeodesicDistance));
            this.m_gc = (GeodesicCoordinate)Marshal.GetDelegateForFunctionPointer(gc, typeof(GeodesicCoordinate));
            this.m_gt = (GeogTran)Marshal.GetDelegateForFunctionPointer(gt, typeof(GeogTran));
            this.m_gg = (GeogGeog)Marshal.GetDelegateForFunctionPointer(gg, typeof(GeogGeog));
        }
        ~Engine() {
            this.Dispose(false);
        }
        public void Dispose() {
            this.Dispose(true);
            GC.SuppressFinalize(this);
        }
        private void Dispose(bool managed) {
            if (this.m_disposed) { return; }
            if (managed) {
                // Dispose of managed resources
            }

            // Dispose unmanaged resources
            if (this.m_pe != IntPtr.Zero) {
                Engine.FreeLibrary(this.m_pe);
            }

            // Update Flag
            this.m_disposed = true;
        }
        /// <summary>
        /// Returns the geodestic azimuth and distance between two geographic locations.
        /// http://edndoc.esri.com/arcsde/9.2/api/capi/geometry/coordsys/pegeodesicdistance.htm
        /// </summary>
        /// <param name="semiMajorAxis">Semi Major Axis</param>
        /// <param name="eccentricity">Globe Eccentricity</param>
        /// <param name="longitude1">From Longitude (radians)</param>
        /// <param name="latitude1">From Latitude (radians)</param>
        /// <param name="longitude2">To Longitude (radians)</param>
        /// <param name="latitude2">To Latitude (radians)</param>
        /// <param name="distance">Returned Geodetic Distance</param>
        /// <param name="azimuthForward">Returned Forward Azimuth (radians)</param>
        /// <param name="azimuthBack">Returned Reverse Azimuth (radians)</param>
        public void GetGeodesicDistance(
            double semiMajorAxis,
            double eccentricity,
            double longitude1,
            double latitude1,
            double longitude2,
            double latitude2,
            out double distance,
            out double azimuthForward,
            out double azimuthBack) {
            this.m_gd(
                semiMajorAxis,
                eccentricity,
                longitude1,
                latitude1,
                longitude2,
                latitude2,
                out distance,
                out azimuthForward,
                out azimuthBack);
        }
        /// <summary>
        /// Returns the geographic location based on the azimuth and distance from another geographic location.
        /// http://edndoc.esri.com/arcsde/9.2/api/capi/geometry/coordsys/pegeodesiccoordinate.htm
        /// </summary>
        /// <param name="semiMajorAxis">Semi Major Axis</param>
        /// <param name="eccentricity">Globe Eccentricity</param>
        /// <param name="longitude1">From Longitude (radians)</param>
        /// <param name="latitude1">From Latitude (radians)</param>
        /// <param name="distance">Distance from "From Location"</param>
        /// <param name="azimuth">Azimuth from "From Location"</param>
        /// <param name="longitude2">Out Logitude (in radians)</param>
        /// <param name="latitude2">Out Latitude (in radians)</param>
        public void GetGeodesicCoordinate(
            double semiMajorAxis,
            double eccentricity,
            double longitude1,
            double latitude1,
            double distance,
            double azimuth,
            out double longitude2,
            out double latitude2) {
            this.m_gc(
                semiMajorAxis,
                eccentricity,
                longitude1,
                latitude1,
                distance,
                azimuth,
                out longitude2,
                out latitude2);
        }
        /// <summary>
        /// Creates the specified geographic transformation object.
        /// http://edndoc.esri.com/arcsde/9.2/api/capi/geometry/coordsys/pefactorygeogtran.htm
        /// http://webhelp.esri.com/arcgisdesktop/9.2/index.cfm?tocVisable=1&ID=100&TopicName=Geographic%20transformation%20methods&pid=99
        /// </summary>
        /// <param name="pegtcode">The code of the predefined geographic transformation object</param>
        /// <returns>Point to the geographic transformation object</returns>
        /// <remarks>
        /// Geographic Transformation codes cane be obtained from here:
        /// http://edndoc.esri.com/arcobjects/9.2/ComponentHelp/esriGeometry/esriSRGeoTransformationType.htm
        /// http://edndoc.esri.com/arcobjects/9.2/ComponentHelp/esriGeometry/esriSRGeoTransformation2Type.htm
        /// http://edndoc.esri.com/arcobjects/9.2/ComponentHelp/esriGeometry/esriSRGeoTransformation3Type.htm
        /// </remarks>
        public IntPtr GetGeogtran(int pegtcode) {
            return this.m_gt(pegtcode);
        }
        /// <summary>
        /// Transforms between geographic coordinate systems in the true order of a PE_GEOGTRAN.
        /// http://edndoc.esri.com/arcsde/9.2/api/capi/geometry/coordsys/pegeog1togeog2.htm
        /// </summary>
        /// <param name="geogtrans">Geographic transformation object</param>
        /// <param name="numpts">Number of points</param>
        /// <param name="coord">Two-dimensional array of points (in decimal degrees)</param>
        /// <param name="h">
        /// Array of ellipsoidal heights. May be a NULL pointer.
        /// If so, all heights are assumed to be zero.
        /// </param>
        /// <returns>Number of points projected successfully</returns>
        public int GetGeog1toGeog2(IntPtr geogtrans, int numpts, double[] coord, double[] h) {
            return this.m_gg(
                geogtrans,
                numpts,
                coord,
                h);
        }

        /// <summary>
        /// Converts Radians to Decimal Degrees.
        /// </summary>
        /// <param name="degrees">In angle in decimal degrees.</param>
        /// <returns>Returns angle in radians.</returns>
        public static double ToRadians(double degrees) {
            return degrees * (Math.PI / 180d);
        }
        /// <summary>
        /// Converts Radians to Decimal Degrees.
        /// </summary>
        /// <param name="radians">In angle in radians.</param>
        /// <returns>Returns angle in decimal degrees.</returns>
        public static double ToDegrees(double radians) {
            return radians * (180d / Math.PI);
        }
        /// <summary>
        /// Converts Decimal Degrees into Degrees Minutes Seconds
        /// </summary>
        /// <param name="coordinate"></param>
        /// <param name="type"></param>
        /// <returns></returns>
        public static string DDtoDMS(double coordinate, CoordinateType type) {
            // Set flag if number is negative
            bool neg = coordinate < 0d;

            // Work with a positive number
            coordinate = Math.Abs(coordinate);

            // Get d/m/s components
            double d = Math.Floor(coordinate);
            coordinate -= d;
            coordinate *= 60;
            double m = Math.Floor(coordinate);
            coordinate -= m;
            coordinate *= 60;
            double s = Math.Round(coordinate);

            // Create padding character
            char pad;
            char.TryParse("0", out pad);

            // Create d/m/s strings
            string dd = d.ToString();
            string mm = m.ToString().PadLeft(2, pad);
            string ss = s.ToString().PadLeft(2, pad);

            // Append d/m/s
            string dms = string.Format("{0}°{1}'{2}\"", dd, mm, ss);

            // Append compass heading
            switch (type) {
                case CoordinateType.longitude:
                    dms += neg ? "W" : "E";
                    break;
                case CoordinateType.latitude:
                    dms += neg ? "S" : "N";
                    break;
            }

            // Return formated string
            return dms;
        }
        private string GetDesltopDll() {
            RegistryKey coreRuntime =
                Registry.LocalMachine.OpenSubKey(@"SOFTWARE\ESRI\CoreRuntime", false);
            if (coreRuntime == null) { return null; }
            object installDir = coreRuntime.GetValue("InstallDir", null);
            coreRuntime.Close();
            if (installDir == null) { return null; }
            string folder = installDir.ToString();
            string bin = Path.Combine(folder, "bin");
            return Path.Combine(bin, "pe.dll");
        }
        private string GetExplorerDll() {
            RegistryKey coreRuntime =
                Registry.LocalMachine.OpenSubKey(@"SOFTWARE\ESRI\E2\CoreRuntime", false);
            if (coreRuntime == null) { return null; }
            object installDir = coreRuntime.GetValue("InstallDir", null);
            coreRuntime.Close();
            if (installDir == null) { return null; }
            string folder = installDir.ToString();
            string bin = Path.Combine(folder, "bin");
            return Path.Combine(bin, "pe.dll");
        }
        private string GetReaderDll() {
            RegistryKey coreRuntime =
                Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Adobe\Acrobat Reader\9.0\Installer", false);
            if (coreRuntime == null) { return null; }
            object installDir = coreRuntime.GetValue("Path", null);
            coreRuntime.Close();
            if (installDir == null) { return null; }
            string folder = installDir.ToString();
            string bin = Path.Combine(folder, "Reader");
            return Path.Combine(bin, "pe.dll");
        }
    }
}

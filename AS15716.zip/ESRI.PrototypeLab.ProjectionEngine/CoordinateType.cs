﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ESRI.PrototypeLab.ProjectionEngine {
    public enum CoordinateType { longitude, latitude };
}

﻿namespace ESRI.PrototypeLab.ProjectionEngine.Test {
    partial class TestApplication {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.buttonDdCalculate = new System.Windows.Forms.Button();
            this.textBoxDd = new System.Windows.Forms.TextBox();
            this.radioButtonDdLat = new System.Windows.Forms.RadioButton();
            this.radioButtonDdLong = new System.Windows.Forms.RadioButton();
            this.groupBoxDD = new System.Windows.Forms.GroupBox();
            this.groupBoxDMS = new System.Windows.Forms.GroupBox();
            this.textBoxDdDms = new System.Windows.Forms.TextBox();
            this.buttonClose = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPageGD = new System.Windows.Forms.TabPage();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.textBoxGdBackwardAzimuth = new System.Windows.Forms.TextBox();
            this.textBoxGdDistance = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBoxGdForwardAzimuth = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.buttonGdCalculate = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.textBoxGdToLong = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxGdToLat = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textBoxGdFromLong = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxGdFromLat = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPageGC = new System.Windows.Forms.TabPage();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.textBoxGcToLong = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.textBoxGcToLat = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.buttonGcCalculate = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.textBoxGcDistance = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.textBoxGcAzimuth = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.textBoxGcFromLong = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.textBoxGcFromLat = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.textBoxGtToLong = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.textBoxGtToLat = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.buttonGtCalculate = new System.Windows.Forms.Button();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.textBoxGtTransformationCode = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.textBoxGtFromLong = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.textBoxGtFromLat = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.tabPageDMS = new System.Windows.Forms.TabPage();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.linkLabel2 = new System.Windows.Forms.LinkLabel();
            this.linkLabel3 = new System.Windows.Forms.LinkLabel();
            this.groupBoxDD.SuspendLayout();
            this.groupBoxDMS.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPageGD.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabPageGC.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.tabPageDMS.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttonDdCalculate
            // 
            this.buttonDdCalculate.Location = new System.Drawing.Point(182, 39);
            this.buttonDdCalculate.Name = "buttonDdCalculate";
            this.buttonDdCalculate.Size = new System.Drawing.Size(30, 34);
            this.buttonDdCalculate.TabIndex = 0;
            this.buttonDdCalculate.Text = ">";
            this.buttonDdCalculate.UseVisualStyleBackColor = true;
            this.buttonDdCalculate.Click += new System.EventHandler(this.Button_Click);
            // 
            // textBoxDd
            // 
            this.textBoxDd.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxDd.Location = new System.Drawing.Point(6, 21);
            this.textBoxDd.Name = "textBoxDd";
            this.textBoxDd.Size = new System.Drawing.Size(154, 22);
            this.textBoxDd.TabIndex = 1;
            this.textBoxDd.Text = "-153.156584";
            // 
            // radioButtonDdLat
            // 
            this.radioButtonDdLat.AutoSize = true;
            this.radioButtonDdLat.Checked = true;
            this.radioButtonDdLat.Location = new System.Drawing.Point(6, 49);
            this.radioButtonDdLat.Name = "radioButtonDdLat";
            this.radioButtonDdLat.Size = new System.Drawing.Size(70, 18);
            this.radioButtonDdLat.TabIndex = 2;
            this.radioButtonDdLat.TabStop = true;
            this.radioButtonDdLat.Text = "Latitude";
            this.radioButtonDdLat.UseVisualStyleBackColor = true;
            // 
            // radioButtonDdLong
            // 
            this.radioButtonDdLong.AutoSize = true;
            this.radioButtonDdLong.Location = new System.Drawing.Point(6, 73);
            this.radioButtonDdLong.Name = "radioButtonDdLong";
            this.radioButtonDdLong.Size = new System.Drawing.Size(80, 18);
            this.radioButtonDdLong.TabIndex = 3;
            this.radioButtonDdLong.Text = "Longitude";
            this.radioButtonDdLong.UseVisualStyleBackColor = true;
            // 
            // groupBoxDD
            // 
            this.groupBoxDD.Controls.Add(this.radioButtonDdLong);
            this.groupBoxDD.Controls.Add(this.radioButtonDdLat);
            this.groupBoxDD.Controls.Add(this.textBoxDd);
            this.groupBoxDD.Location = new System.Drawing.Point(6, 6);
            this.groupBoxDD.Name = "groupBoxDD";
            this.groupBoxDD.Size = new System.Drawing.Size(170, 100);
            this.groupBoxDD.TabIndex = 5;
            this.groupBoxDD.TabStop = false;
            this.groupBoxDD.Text = "Decimal Degrees";
            // 
            // groupBoxDMS
            // 
            this.groupBoxDMS.Controls.Add(this.textBoxDdDms);
            this.groupBoxDMS.Location = new System.Drawing.Point(218, 6);
            this.groupBoxDMS.Name = "groupBoxDMS";
            this.groupBoxDMS.Size = new System.Drawing.Size(170, 100);
            this.groupBoxDMS.TabIndex = 6;
            this.groupBoxDMS.TabStop = false;
            this.groupBoxDMS.Text = "Degrees Minutes Seconds";
            // 
            // textBoxDdDms
            // 
            this.textBoxDdDms.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxDdDms.Location = new System.Drawing.Point(6, 21);
            this.textBoxDdDms.Name = "textBoxDdDms";
            this.textBoxDdDms.Size = new System.Drawing.Size(158, 22);
            this.textBoxDdDms.TabIndex = 0;
            // 
            // buttonClose
            // 
            this.buttonClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonClose.Location = new System.Drawing.Point(489, 274);
            this.buttonClose.Name = "buttonClose";
            this.buttonClose.Size = new System.Drawing.Size(75, 23);
            this.buttonClose.TabIndex = 7;
            this.buttonClose.Text = "Close";
            this.buttonClose.UseVisualStyleBackColor = true;
            this.buttonClose.Click += new System.EventHandler(this.Button_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.tabPageGD);
            this.tabControl1.Controls.Add(this.tabPageGC);
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPageDMS);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(552, 256);
            this.tabControl1.TabIndex = 8;
            // 
            // tabPageGD
            // 
            this.tabPageGD.Controls.Add(this.groupBox3);
            this.tabPageGD.Controls.Add(this.buttonGdCalculate);
            this.tabPageGD.Controls.Add(this.groupBox2);
            this.tabPageGD.Controls.Add(this.groupBox1);
            this.tabPageGD.Location = new System.Drawing.Point(4, 23);
            this.tabPageGD.Name = "tabPageGD";
            this.tabPageGD.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageGD.Size = new System.Drawing.Size(544, 229);
            this.tabPageGD.TabIndex = 0;
            this.tabPageGD.Text = "Geodesic Distance";
            this.tabPageGD.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.textBoxGdBackwardAzimuth);
            this.groupBox3.Controls.Add(this.textBoxGdDistance);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.textBoxGdForwardAzimuth);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Location = new System.Drawing.Point(235, 39);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(225, 113);
            this.groupBox3.TabIndex = 5;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Geodesic Line Between Is:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(112, 80);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(107, 14);
            this.label7.TabIndex = 5;
            this.label7.Text = "Backward Azimuth";
            // 
            // textBoxGdBackwardAzimuth
            // 
            this.textBoxGdBackwardAzimuth.Location = new System.Drawing.Point(6, 77);
            this.textBoxGdBackwardAzimuth.Name = "textBoxGdBackwardAzimuth";
            this.textBoxGdBackwardAzimuth.Size = new System.Drawing.Size(100, 22);
            this.textBoxGdBackwardAzimuth.TabIndex = 4;
            // 
            // textBoxGdDistance
            // 
            this.textBoxGdDistance.Location = new System.Drawing.Point(6, 21);
            this.textBoxGdDistance.Name = "textBoxGdDistance";
            this.textBoxGdDistance.Size = new System.Drawing.Size(100, 22);
            this.textBoxGdDistance.TabIndex = 0;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(112, 52);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(99, 14);
            this.label5.TabIndex = 3;
            this.label5.Text = "Forward Azimuth";
            // 
            // textBoxGdForwardAzimuth
            // 
            this.textBoxGdForwardAzimuth.Location = new System.Drawing.Point(6, 49);
            this.textBoxGdForwardAzimuth.Name = "textBoxGdForwardAzimuth";
            this.textBoxGdForwardAzimuth.Size = new System.Drawing.Size(100, 22);
            this.textBoxGdForwardAzimuth.TabIndex = 1;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(112, 24);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(77, 14);
            this.label6.TabIndex = 2;
            this.label6.Text = "Distance (m)";
            // 
            // buttonGdCalculate
            // 
            this.buttonGdCalculate.Location = new System.Drawing.Point(199, 76);
            this.buttonGdCalculate.Name = "buttonGdCalculate";
            this.buttonGdCalculate.Size = new System.Drawing.Size(30, 34);
            this.buttonGdCalculate.TabIndex = 6;
            this.buttonGdCalculate.Text = ">";
            this.buttonGdCalculate.UseVisualStyleBackColor = true;
            this.buttonGdCalculate.Click += new System.EventHandler(this.Button_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.textBoxGdToLong);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.textBoxGdToLat);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Location = new System.Drawing.Point(6, 97);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(187, 85);
            this.groupBox2.TabIndex = 5;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "To";
            // 
            // textBoxGdToLong
            // 
            this.textBoxGdToLong.Location = new System.Drawing.Point(6, 21);
            this.textBoxGdToLong.Name = "textBoxGdToLong";
            this.textBoxGdToLong.Size = new System.Drawing.Size(100, 22);
            this.textBoxGdToLong.TabIndex = 0;
            this.textBoxGdToLong.Text = "48.86";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(112, 52);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(52, 14);
            this.label3.TabIndex = 3;
            this.label3.Text = "Latitude";
            // 
            // textBoxGdToLat
            // 
            this.textBoxGdToLat.Location = new System.Drawing.Point(6, 49);
            this.textBoxGdToLat.Name = "textBoxGdToLat";
            this.textBoxGdToLat.Size = new System.Drawing.Size(100, 22);
            this.textBoxGdToLat.TabIndex = 1;
            this.textBoxGdToLat.Text = "2.35";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(112, 24);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(62, 14);
            this.label4.TabIndex = 2;
            this.label4.Text = "Longitude";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.textBoxGdFromLong);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.textBoxGdFromLat);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(6, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(187, 85);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "From";
            // 
            // textBoxGdFromLong
            // 
            this.textBoxGdFromLong.Location = new System.Drawing.Point(6, 21);
            this.textBoxGdFromLong.Name = "textBoxGdFromLong";
            this.textBoxGdFromLong.Size = new System.Drawing.Size(100, 22);
            this.textBoxGdFromLong.TabIndex = 0;
            this.textBoxGdFromLong.Text = "51.50";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(112, 52);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 14);
            this.label2.TabIndex = 3;
            this.label2.Text = "Latitude";
            // 
            // textBoxGdFromLat
            // 
            this.textBoxGdFromLat.Location = new System.Drawing.Point(6, 49);
            this.textBoxGdFromLat.Name = "textBoxGdFromLat";
            this.textBoxGdFromLat.Size = new System.Drawing.Size(100, 22);
            this.textBoxGdFromLat.TabIndex = 1;
            this.textBoxGdFromLat.Text = "-0.12";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(112, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 14);
            this.label1.TabIndex = 2;
            this.label1.Text = "Longitude";
            // 
            // tabPageGC
            // 
            this.tabPageGC.Controls.Add(this.groupBox6);
            this.tabPageGC.Controls.Add(this.buttonGcCalculate);
            this.tabPageGC.Controls.Add(this.groupBox5);
            this.tabPageGC.Controls.Add(this.groupBox4);
            this.tabPageGC.Location = new System.Drawing.Point(4, 23);
            this.tabPageGC.Name = "tabPageGC";
            this.tabPageGC.Size = new System.Drawing.Size(544, 229);
            this.tabPageGC.TabIndex = 2;
            this.tabPageGC.Text = "Geodesic Coordinate";
            this.tabPageGC.UseVisualStyleBackColor = true;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.textBoxGcToLong);
            this.groupBox6.Controls.Add(this.label10);
            this.groupBox6.Controls.Add(this.textBoxGcToLat);
            this.groupBox6.Controls.Add(this.label13);
            this.groupBox6.Location = new System.Drawing.Point(251, 47);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(187, 85);
            this.groupBox6.TabIndex = 8;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "To";
            // 
            // textBoxGcToLong
            // 
            this.textBoxGcToLong.Location = new System.Drawing.Point(6, 21);
            this.textBoxGcToLong.Name = "textBoxGcToLong";
            this.textBoxGcToLong.Size = new System.Drawing.Size(100, 22);
            this.textBoxGcToLong.TabIndex = 0;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(112, 52);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(52, 14);
            this.label10.TabIndex = 3;
            this.label10.Text = "Latitude";
            // 
            // textBoxGcToLat
            // 
            this.textBoxGcToLat.Location = new System.Drawing.Point(6, 49);
            this.textBoxGcToLat.Name = "textBoxGcToLat";
            this.textBoxGcToLat.Size = new System.Drawing.Size(100, 22);
            this.textBoxGcToLat.TabIndex = 1;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(112, 24);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(62, 14);
            this.label13.TabIndex = 2;
            this.label13.Text = "Longitude";
            // 
            // buttonGcCalculate
            // 
            this.buttonGcCalculate.Location = new System.Drawing.Point(215, 75);
            this.buttonGcCalculate.Name = "buttonGcCalculate";
            this.buttonGcCalculate.Size = new System.Drawing.Size(30, 34);
            this.buttonGcCalculate.TabIndex = 7;
            this.buttonGcCalculate.Text = ">";
            this.buttonGcCalculate.UseVisualStyleBackColor = true;
            this.buttonGcCalculate.Click += new System.EventHandler(this.Button_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.textBoxGcDistance);
            this.groupBox5.Controls.Add(this.label11);
            this.groupBox5.Controls.Add(this.textBoxGcAzimuth);
            this.groupBox5.Controls.Add(this.label12);
            this.groupBox5.Location = new System.Drawing.Point(3, 94);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(206, 85);
            this.groupBox5.TabIndex = 6;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Geodesic Line Between Is:";
            // 
            // textBoxGcDistance
            // 
            this.textBoxGcDistance.Location = new System.Drawing.Point(6, 21);
            this.textBoxGcDistance.Name = "textBoxGcDistance";
            this.textBoxGcDistance.Size = new System.Drawing.Size(100, 22);
            this.textBoxGcDistance.TabIndex = 0;
            this.textBoxGcDistance.Tag = "";
            this.textBoxGcDistance.Text = "401723";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(112, 52);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(51, 14);
            this.label11.TabIndex = 3;
            this.label11.Text = "Azimuth";
            // 
            // textBoxGcAzimuth
            // 
            this.textBoxGcAzimuth.Location = new System.Drawing.Point(6, 49);
            this.textBoxGcAzimuth.Name = "textBoxGcAzimuth";
            this.textBoxGcAzimuth.Size = new System.Drawing.Size(100, 22);
            this.textBoxGcAzimuth.TabIndex = 1;
            this.textBoxGcAzimuth.Text = "-46.88";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(112, 24);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(77, 14);
            this.label12.TabIndex = 2;
            this.label12.Text = "Distance (m)";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.textBoxGcFromLong);
            this.groupBox4.Controls.Add(this.label8);
            this.groupBox4.Controls.Add(this.textBoxGcFromLat);
            this.groupBox4.Controls.Add(this.label9);
            this.groupBox4.Location = new System.Drawing.Point(3, 3);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(206, 85);
            this.groupBox4.TabIndex = 5;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "From";
            // 
            // textBoxGcFromLong
            // 
            this.textBoxGcFromLong.Location = new System.Drawing.Point(6, 21);
            this.textBoxGcFromLong.Name = "textBoxGcFromLong";
            this.textBoxGcFromLong.Size = new System.Drawing.Size(100, 22);
            this.textBoxGcFromLong.TabIndex = 0;
            this.textBoxGcFromLong.Text = "51.50";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(112, 52);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(52, 14);
            this.label8.TabIndex = 3;
            this.label8.Text = "Latitude";
            // 
            // textBoxGcFromLat
            // 
            this.textBoxGcFromLat.Location = new System.Drawing.Point(6, 49);
            this.textBoxGcFromLat.Name = "textBoxGcFromLat";
            this.textBoxGcFromLat.Size = new System.Drawing.Size(100, 22);
            this.textBoxGcFromLat.TabIndex = 1;
            this.textBoxGcFromLat.Text = "-0.12";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(112, 24);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(62, 14);
            this.label9.TabIndex = 2;
            this.label9.Text = "Longitude";
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.groupBox7);
            this.tabPage1.Controls.Add(this.buttonGtCalculate);
            this.tabPage1.Controls.Add(this.groupBox8);
            this.tabPage1.Controls.Add(this.groupBox9);
            this.tabPage1.Location = new System.Drawing.Point(4, 23);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(544, 229);
            this.tabPage1.TabIndex = 3;
            this.tabPage1.Text = "Geographic Transformation";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.textBoxGtToLong);
            this.groupBox7.Controls.Add(this.label14);
            this.groupBox7.Controls.Add(this.textBoxGtToLat);
            this.groupBox7.Controls.Add(this.label15);
            this.groupBox7.Location = new System.Drawing.Point(254, 50);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(187, 85);
            this.groupBox7.TabIndex = 12;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "To";
            // 
            // textBoxGtToLong
            // 
            this.textBoxGtToLong.Location = new System.Drawing.Point(6, 21);
            this.textBoxGtToLong.Name = "textBoxGtToLong";
            this.textBoxGtToLong.Size = new System.Drawing.Size(100, 22);
            this.textBoxGtToLong.TabIndex = 0;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(112, 52);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(52, 14);
            this.label14.TabIndex = 3;
            this.label14.Text = "Latitude";
            // 
            // textBoxGtToLat
            // 
            this.textBoxGtToLat.Location = new System.Drawing.Point(6, 49);
            this.textBoxGtToLat.Name = "textBoxGtToLat";
            this.textBoxGtToLat.Size = new System.Drawing.Size(100, 22);
            this.textBoxGtToLat.TabIndex = 1;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(112, 24);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(62, 14);
            this.label15.TabIndex = 2;
            this.label15.Text = "Longitude";
            // 
            // buttonGtCalculate
            // 
            this.buttonGtCalculate.Location = new System.Drawing.Point(218, 78);
            this.buttonGtCalculate.Name = "buttonGtCalculate";
            this.buttonGtCalculate.Size = new System.Drawing.Size(30, 34);
            this.buttonGtCalculate.TabIndex = 11;
            this.buttonGtCalculate.Text = ">";
            this.buttonGtCalculate.UseVisualStyleBackColor = true;
            this.buttonGtCalculate.Click += new System.EventHandler(this.Button_Click);
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.linkLabel3);
            this.groupBox8.Controls.Add(this.textBoxGtTransformationCode);
            this.groupBox8.Controls.Add(this.linkLabel2);
            this.groupBox8.Controls.Add(this.label17);
            this.groupBox8.Controls.Add(this.linkLabel1);
            this.groupBox8.Location = new System.Drawing.Point(6, 97);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(206, 99);
            this.groupBox8.TabIndex = 10;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Transformation Code";
            // 
            // textBoxGtTransformationCode
            // 
            this.textBoxGtTransformationCode.Location = new System.Drawing.Point(6, 21);
            this.textBoxGtTransformationCode.Name = "textBoxGtTransformationCode";
            this.textBoxGtTransformationCode.Size = new System.Drawing.Size(100, 22);
            this.textBoxGtTransformationCode.TabIndex = 0;
            this.textBoxGtTransformationCode.Tag = "";
            this.textBoxGtTransformationCode.Text = "1111";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(112, 24);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(0, 14);
            this.label17.TabIndex = 2;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.textBoxGtFromLong);
            this.groupBox9.Controls.Add(this.label18);
            this.groupBox9.Controls.Add(this.textBoxGtFromLat);
            this.groupBox9.Controls.Add(this.label19);
            this.groupBox9.Location = new System.Drawing.Point(6, 6);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(206, 85);
            this.groupBox9.TabIndex = 9;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "From";
            // 
            // textBoxGtFromLong
            // 
            this.textBoxGtFromLong.Location = new System.Drawing.Point(6, 21);
            this.textBoxGtFromLong.Name = "textBoxGtFromLong";
            this.textBoxGtFromLong.Size = new System.Drawing.Size(100, 22);
            this.textBoxGtFromLong.TabIndex = 0;
            this.textBoxGtFromLong.Text = "38.2080611";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(112, 52);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(52, 14);
            this.label18.TabIndex = 3;
            this.label18.Text = "Latitude";
            // 
            // textBoxGtFromLat
            // 
            this.textBoxGtFromLat.Location = new System.Drawing.Point(6, 49);
            this.textBoxGtFromLat.Name = "textBoxGtFromLat";
            this.textBoxGtFromLat.Size = new System.Drawing.Size(100, 22);
            this.textBoxGtFromLat.TabIndex = 1;
            this.textBoxGtFromLat.Text = "28.23671389";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(112, 24);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(62, 14);
            this.label19.TabIndex = 2;
            this.label19.Text = "Longitude";
            // 
            // tabPageDMS
            // 
            this.tabPageDMS.Controls.Add(this.groupBoxDD);
            this.tabPageDMS.Controls.Add(this.buttonDdCalculate);
            this.tabPageDMS.Controls.Add(this.groupBoxDMS);
            this.tabPageDMS.Location = new System.Drawing.Point(4, 23);
            this.tabPageDMS.Name = "tabPageDMS";
            this.tabPageDMS.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageDMS.Size = new System.Drawing.Size(544, 229);
            this.tabPageDMS.TabIndex = 1;
            this.tabPageDMS.Text = "DD to DMS";
            this.tabPageDMS.UseVisualStyleBackColor = true;
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Location = new System.Drawing.Point(3, 46);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(151, 14);
            this.linkLabel1.TabIndex = 13;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "List of Transformations #1";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // linkLabel2
            // 
            this.linkLabel2.AutoSize = true;
            this.linkLabel2.Location = new System.Drawing.Point(3, 60);
            this.linkLabel2.Name = "linkLabel2";
            this.linkLabel2.Size = new System.Drawing.Size(151, 14);
            this.linkLabel2.TabIndex = 14;
            this.linkLabel2.TabStop = true;
            this.linkLabel2.Text = "List of Transformations #2";
            this.linkLabel2.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // linkLabel3
            // 
            this.linkLabel3.AutoSize = true;
            this.linkLabel3.Location = new System.Drawing.Point(3, 74);
            this.linkLabel3.Name = "linkLabel3";
            this.linkLabel3.Size = new System.Drawing.Size(151, 14);
            this.linkLabel3.TabIndex = 15;
            this.linkLabel3.TabStop = true;
            this.linkLabel3.Text = "List of Transformations #3";
            this.linkLabel3.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // TestApplication
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(576, 309);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.buttonClose);
            this.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "TestApplication";
            this.Text = "Test Application";
            this.groupBoxDD.ResumeLayout(false);
            this.groupBoxDD.PerformLayout();
            this.groupBoxDMS.ResumeLayout(false);
            this.groupBoxDMS.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPageGD.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabPageGC.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.tabPageDMS.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonDdCalculate;
        private System.Windows.Forms.TextBox textBoxDd;
        private System.Windows.Forms.RadioButton radioButtonDdLat;
        private System.Windows.Forms.RadioButton radioButtonDdLong;
        private System.Windows.Forms.GroupBox groupBoxDD;
        private System.Windows.Forms.GroupBox groupBoxDMS;
        private System.Windows.Forms.TextBox textBoxDdDms;
        private System.Windows.Forms.Button buttonClose;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPageGD;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBoxGdFromLat;
        private System.Windows.Forms.TextBox textBoxGdFromLong;
        private System.Windows.Forms.TabPage tabPageGC;
        private System.Windows.Forms.TabPage tabPageDMS;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox textBoxGdToLong;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxGdToLat;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button buttonGdCalculate;
        private System.Windows.Forms.TextBox textBoxGdBackwardAzimuth;
        private System.Windows.Forms.TextBox textBoxGdDistance;
        private System.Windows.Forms.TextBox textBoxGdForwardAzimuth;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TextBox textBoxGcDistance;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBoxGcAzimuth;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox textBoxGcFromLong;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBoxGcFromLat;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TextBox textBoxGcToLong;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBoxGcToLat;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button buttonGcCalculate;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.TextBox textBoxGtToLong;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox textBoxGtToLat;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button buttonGtCalculate;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.TextBox textBoxGtTransformationCode;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.TextBox textBoxGtFromLong;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox textBoxGtFromLat;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.LinkLabel linkLabel3;
        private System.Windows.Forms.LinkLabel linkLabel2;
        private System.Windows.Forms.LinkLabel linkLabel1;
    }
}


﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using ESRI.PrototypeLab.ProjectionEngine;
using System.Diagnostics;

namespace ESRI.PrototypeLab.ProjectionEngine.Test {
    public partial class TestApplication : Form {
        private Engine m_engine = null;
        public TestApplication() {
            InitializeComponent();

            // Create Instance of the Projection Engine
            this.m_engine = new Engine(EngineType.ArcGISDesktop);
        }
        private void Button_Click(object sender, EventArgs e) {
            if (sender == this.buttonGdCalculate) {
                double fromLong;
                double fromLat;
                double toLong;
                double toLat;
                if (!double.TryParse(this.textBoxGdFromLong.Text, out fromLong)) { return; }
                if (!double.TryParse(this.textBoxGdFromLat.Text, out fromLat)) { return; }
                if (!double.TryParse(this.textBoxGdToLong.Text, out toLong)) { return; }
                if (!double.TryParse(this.textBoxGdToLat.Text, out toLat)) { return; }
                double distance = 0d;
                double azimuthForward = 0d;
                double azimuthBack = 0d;
                this.m_engine.GetGeodesicDistance(
                    Engine.GLOBERADIUS,
                    0,
                    Engine.ToRadians(fromLong),
                    Engine.ToRadians(fromLat),
                    Engine.ToRadians(toLong),
                    Engine.ToRadians(toLat),
                    out distance,
                    out azimuthForward,
                    out azimuthBack);
                this.textBoxGdDistance.Text = distance.ToString();
                this.textBoxGdForwardAzimuth.Text = Engine.ToDegrees(azimuthForward).ToString();
                this.textBoxGdBackwardAzimuth.Text = Engine.ToDegrees(azimuthBack).ToString();
            }
            else if (sender == this.buttonGcCalculate) {
                double fromLong;
                double fromLat;
                double distance;
                double azimuth;
                if (!double.TryParse(this.textBoxGcFromLong.Text, out fromLong)) { return; }
                if (!double.TryParse(this.textBoxGcFromLat.Text, out fromLat)) { return; }
                if (!double.TryParse(this.textBoxGcDistance.Text, out distance)) { return; }
                if (!double.TryParse(this.textBoxGcAzimuth.Text, out azimuth)) { return; }
                double toLong;
                double toLat;
                this.m_engine.GetGeodesicCoordinate(
                    Engine.GLOBERADIUS,
                    0d,
                    Engine.ToRadians(fromLong),
                    Engine.ToRadians(fromLat),
                    distance,
                    Engine.ToRadians(azimuth),
                    out toLong,
                    out toLat);
                this.textBoxGcToLong.Text = Engine.ToDegrees(toLong).ToString();
                this.textBoxGcToLat.Text = Engine.ToDegrees(toLat).ToString();
            }
            else if (sender == this.buttonGtCalculate) {
                double fromLong;
                double fromLat;
                int code;
                if (!double.TryParse(this.textBoxGtFromLong.Text, out fromLong)) { return; }
                if (!double.TryParse(this.textBoxGtFromLat.Text, out fromLat)) { return; }
                if (!int.TryParse(this.textBoxGtTransformationCode.Text, out code)) { return; }
                IntPtr trans = this.m_engine.GetGeogtran(code);
                double[] array = new double[] { fromLong, fromLat };
                int pointsOk = this.m_engine.GetGeog1toGeog2(trans, array.Length, array, null);
                if (pointsOk < array.Length) {
                    MessageBox.Show("One or more points could not be transformed");
                    return;
                }
                this.textBoxGtToLong.Text = array[0].ToString();
                this.textBoxGtToLat.Text = array[1].ToString();
            }
            else if (sender == this.buttonDdCalculate) {
                if (string.IsNullOrEmpty(this.textBoxDd.Text)) { return; }
                double d;
                if (!double.TryParse(this.textBoxDd.Text, out d)) { return; }
                CoordinateType type = this.radioButtonDdLat.Checked ? CoordinateType.latitude : CoordinateType.longitude;
                this.textBoxDdDms.Text = Engine.DDtoDMS(d, type);
            }
            else if (sender == this.buttonClose) {
                this.Close();
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e) {
            string url = null;
            if (sender == this.linkLabel1) {
               url = "http://edndoc.esri.com/arcobjects/9.2/ComponentHelp/esriGeometry/esriSRGeoTransformationType.htm";
            }
            else if (sender == this.linkLabel2) {
                url = "http://edndoc.esri.com/arcobjects/9.2/ComponentHelp/esriGeometry/esriSRGeoTransformation2Type.htm";
            }
            else if (sender == this.linkLabel3) {
                url = "http://edndoc.esri.com/arcobjects/9.2/ComponentHelp/esriGeometry/esriSRGeoTransformation3Type.htm";
            }
            if (string.IsNullOrEmpty(url)) { return; }
            Process process = new Process();
            process.StartInfo.FileName = url;
            process.StartInfo.Verb = "Open";
            process.StartInfo.CreateNoWindow = false;
            process.Start();
        }
    }
}
